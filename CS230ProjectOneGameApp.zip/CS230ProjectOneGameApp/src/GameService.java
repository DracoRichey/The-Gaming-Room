public class GameService {
    private static GameService instance = null;
    // Example of static variables to hold the next identifiers
    private static int nextGameId = 1;
    private static int nextTeamId = 1;
    private static int nextPlayerId = 1;

    private GameService() { }

    public static GameService getInstance() {
        if (instance == null) {
            instance = new GameService();
        }
        return instance;
    }

    // Method add game, team, player.
}